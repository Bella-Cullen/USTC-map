// app.js
App({
  onLaunch:function(){
    var that=this;
    wx.cloud.init({
      env:'cloud1-4g5vv45i69fe6223',
    })

    wx.cloud.callFunction({
      name:'getUserOpenid',
      success(res){
        that.globalData.openid=res.result.openid
      }
    })


  },
// 用户信息
  globalData:{
    userinfo:null,
    openid:null
  }




})
