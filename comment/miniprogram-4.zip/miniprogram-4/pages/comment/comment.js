let store=false;
Page({
  data:{
    imgUrl:"./../images/notstored.png",
  },
  
  collect(){

    if(store)
    {
      this.setData({
        imgUrl:"./../images/notstored.png",
      })
      store=false
    }
    else{
      this.setData({
        imgUrl:"./../images/stored.png",
      })
      store=true
    }
  }
})