// pages/detail/detail.js
let store=false;
let ID='';
//let pinglun=[];
Page({
  data:{
    detail:'',
    imgUrl:"./../images/notstored.png",
    pinglun:[],
    content:'',
  },

onLoad(options){
  ID=options.id;
  console.log("id",ID)
  wx.cloud.database().collection('homelist').doc(ID)
  .get()
  .then(res=>{
    console.log("success",res)
    store=res.data.shoucang;
    this.setData({
      detail:res.data,
      imgUrl:res.data.shoucang?"./../images/stored.png":"./../images/notstored.png",
      pinglun:res.data.comment,
    })
  })
  .catch(res=>{
    console.log("fail")
  })
},

//收藏
collect(){
    this.setData({
      imgUrl:store?"./../images/notstored.png":"./../images/stored.png",
    })
    store=!store
    wx.cloud.callFunction({
      name:"shoucang",
      data:{
        action:"shoucang",
        id:ID,
        store:store,
      }
    }).then(res=>{
      console.log("success",res)
    })
    .catch(res=>{
      console.log("fail",res)
    })
},

//获取评论内容
getContent(event){
  console.log("评论",event.detail.value)
  this.setData({
    content:event.detail.value,
  })
  
},

comment(){
  if(this.data.content.length<3)
  {
    wx.showToast({
      icon:"none",
      title: '字数不足！',
    })
    return
  }
  let commentItem={};
  commentItem.name="sb";
  commentItem.content=this.data.content;
  let pinglunArr=this.data.pinglun
  pinglunArr.push(commentItem);
  console.log("添加",pinglunArr)
  wx.cloud.callFunction({
    name:"shoucang",
    data:{
      action:"pinglun",
      id:ID,
      pinglun:pinglunArr,
    }
  }).then(res=>{
    console.log("success",res)
    this.setData({
      pinglun:pinglunArr,
      content:''
    })
  })
  .catch(res=>{
    console.log("fail",res)
  })
},

})