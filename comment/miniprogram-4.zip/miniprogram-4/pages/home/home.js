Page({
  data:{
    datalist:[],
  },

  onLoad(){
    //取数据库里数据
    wx.cloud.database().collection('homelist').get()
    .then(res=>{
      console.log("success",res)
      this.setData({
        datalist:res.data
      })
    })
    .catch(res=>{
      console.log("fail",res)
    })

  },

  goDetail(event){
    console.log(event.currentTarget.dataset.item._id)
    wx.navigateTo({
      url: '/pages/detail/detail?id='+event.currentTarget.dataset.item._id,
    })
  },
})